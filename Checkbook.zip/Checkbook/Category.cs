﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Checkbook
{
    public class Category : IComparable<Category>
    {
        private string title;           // Name of the category
        private decimal amount;         // The amount in the category

        public Category(string strTitle, decimal decAmount)
        {
            Title = strTitle;
            Amount = decAmount;
        }
        public string Title
        {
            get { return title; }
            set { title = value; }
        }
        public decimal Amount
        {
            get { return amount; }
            set { amount = value; }
        }
        public override string ToString()
        {
            return Title + "\t" + Amount.ToString("C");
        }

        public int CompareTo(Category other)
        {
            return Title.CompareTo(other.Title);
        }
    }
}
