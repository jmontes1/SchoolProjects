﻿// Checkbook - Final
// Jorge Montes - 3/7/2017
// Creating Client Applications in C#
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Checkbook
{
    /// <summary>
    /// Chekbook class - Interaction logic for EditTransaction.xaml
    /// </summary>
    public partial class EditTransaction : Window
    {
        public EditTransaction(Transaction tr)
        {
            /// <summary>
            /// EditTransaction class - Used to edit Transaction object fields
            /// </summary>

            InitializeComponent();
            
            textBox_ID.Text = tr.Id.ToString();
            textBox_Type.Text = tr.Type.ToString();
            textBox_Desc.Text = tr.Description.ToString();
            textBox_Date.Text = tr.Date.ToShortDateString();
            label_AmtString.Content = tr.AmountString;
            textBox_Amount.Text = tr.Amount.ToString("#.00");
            comboBox_Category.Text = tr.Category;
            textBox_Checknum.Text = tr.Checknum;
        }

        private void button_OK_Click(object sender, RoutedEventArgs e)
        {
            /// <summary>
            /// OK Button logic - Returns true if OK button was clicked (when closed)
            /// </summary>

            DialogResult = true;
            Close();
        }

        private void button_Cancel_Click(object sender, RoutedEventArgs e)
        {
            /// <summary>
            /// Cancel Button logic - Returns false if Cancel button was clicked (when closed)
            /// </summary>

            DialogResult = false;
            Close();
        }
    }
}
