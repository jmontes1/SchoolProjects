﻿// Checkbook - Final
// Jorge Montes - 3/7/2017
// Creating Client Applications in C#
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;    // Needed to implement interface INotifyPropertyChanged
using System.Windows;

namespace Checkbook
{
    public enum TransactionType { Check, Debit, Deposit }
    abstract public class Transaction : INotifyPropertyChanged
    {
        /// <summary>
        /// Transaction class to maintain Transaction data
        /// </summary>

        private static int lastId = 0;

        private int id;                 // Transaction ID
        private TransactionType type;   // Type of transaction
        private string category;        // Category (Budget)
        private DateTime date;          // Date of transaction
        private string description;     // Paid to, taken from...
        private decimal amount;         // The amount (always > 0)
        private string checknum;        // Check # if appropriate

        public Transaction(DateTime dateTime, TransactionType type, string description, string category, decimal amount,
            string checknum = "")
        {
            /// <summary>
            /// Constructor to create Transaction object
            /// </summary>
            /// <param name="dateTime">Date of transaction</param>
            /// <param name="type">Transaction type</param>
            /// <param name="description">Transaction description</param>
            /// <param name="category">Transaction category type (Debit, Credit, etc)</param>
            /// <param name="amount">Transaction amount</param>
            /// <param name="checknum">Check number, if applicable</param>
            /// <returns>Transaction object</returns>
            id = nextId();
            Date = dateTime;
            Type = type;
            Description = description;
            Category = category;
            Amount = amount;
            Checknum = checknum;
        }
        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyChanged(string property)
        {
            /// <summary>
            /// Used to implement INotifyPropertyChanged interface
            /// </summary>
            if (PropertyChanged != null)
            {
                PropertyChanged.Invoke(this, new PropertyChangedEventArgs(property));
            }
        }
        // Properties
        public int Id
        {
            get { return id; }
            private set { id = value; NotifyChanged("Id"); }
        }
        public TransactionType Type
        {
            get { return type; }
            set { type = value; NotifyChanged("Type"); }
        }
        public string Category
        {
            get { return category; }
            set { category = value; NotifyChanged("Category"); }
        }
        public DateTime Date
        {
            get { return date; }
            set { date = value; NotifyChanged("Date"); }
        }
        public string Description
        {
            get { return description; }
            set { description = value; NotifyChanged("Description"); }
        }
        public decimal Amount
        {
            get { return amount; }
            set { amount = value;
                  NotifyChanged("Amount");
                  NotifyChanged("AmountString");
                  NotifyChanged("CalculationAmount");
            }
        }
        public string Checknum
        {
            get { return checknum; }
            set { checknum = value; NotifyChanged("Checknum"); }
        }
        public string TransactionSummary
        {
            get { return ToString(); }
        }
        int nextId()
        {
            return ++lastId;
        }
        // Property creates and returns the amount string using using the functions below
        public string AmountString
        {
            get
            {
                StringBuilder strAmt = new StringBuilder();
                int dollars = (int)Amount;
                int cents = (int)(Amount * 100 % 100);
                strAmt.Append(amtToString(dollars) + " and " + amtToString(cents, true) + "/100s Dollars");
                strAmt[0] = char.ToUpper(strAmt[0]);
                return strAmt.ToString();
            }
        }
        // Returns dollars in text ("Three hundred seventy two"), or if useDigits, return 372)
        private string amtToString(int amt, bool useDigits = false)
        {
            /// <summary>
            /// Main helper program used to create amount verbiage
            /// </summary>
            /// <returns>String to display</returns>
            if (amt == 0) return (useDigits ? "00" : "zero");   // If amount is zero, no need to go further
            if (useDigits) return amt.ToString();               // If using digits, return just the digits

            StringBuilder strAmt = new StringBuilder();         // The whole string goes in here
            int[] groups = { 1000000000, 1000000, 1000, 1 };    // Our words repeat in 3s (thousand, million)

            foreach (int grp in groups)
            {
                if (amt < grp) continue;                        // If nothing in this sub-group, skip it
                int v = amt / grp;                              // Separate the 0-999 portion of grouping
                hundredsToString(v, strAmt, grp);               // Append the current grouping
                amt = amt % grp;                                // Remove grouping we're printing from left to do
            }
            return strAmt.ToString();
        }
        // Convert a "hundreds" group into text
        // Our number system repeats every 3 digits (thousands, millions, billions, etc)
        // This processes one of those 3 digits groups.
        // params: amt = The amount to print.  Must be 0-999
        //         strAmt = The StringBuilder object in which to write the text
        //         grouping = The grouping (1, 1000000, 1000000000 )
        private void hundredsToString(int amt, StringBuilder strAmt, int grouping)
        {
            String[] label = { "", "thousand", "million", "billion" };  // The grouping labels
            int group = 0;                                              // Determine which group to use
            if (grouping >= 1000) group++;
            if (grouping >= 1000000) group++;
            if (grouping >= 1000000000) group++;

            if (amt >= 100)                                 // Do we need a "hundreds" value for this number
            {
                int h = amt / 100;                          // Strip out the hundreds from the rest of the number
                numberToString(h, strAmt);                  // Add the hundreds value
                appendWithSpace(strAmt, "hundred");
                amt = amt % 100;                            // Remove what we've already printed
            }
            numberToString(amt, strAmt);                    // Print the remaining value along with the grouping
            appendWithSpace(strAmt, label[group]);
            return;
        }
        // Convert a number (0-999) to a string.
        // params:  amt = The number to convert
        //          strAmt = The StringBuilder where the string value should be added
        private void numberToString(int amt, StringBuilder strAmt)
        {
            String[] nums = {"", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten",
                "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen",
                "nineteen"};
            String[] tens = { "", "ten", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety" };

            if (amt < 20)                                   // We have special cases for numbers less than 20
            {
                appendWithSpace(strAmt, nums[amt]);
            }
            else
            {
                appendWithSpace(strAmt, tens[amt / 10]);
                appendWithSpace(strAmt, nums[amt % 10]);
            }
        }
        // Append a string to the StringBuilder, adding a space first if there's any existing text
        private void appendWithSpace(StringBuilder sb, String s)
        {
            if (s.Length == 0) return;                      // If no text to append, return
            if (sb.Length > 0) sb.Append(" ");              // If there's any existing text, add a space
            sb.Append(s);                                   // Append the text to the StringBuilder
        }
        public override string ToString()
        {
            return Date.ToShortDateString() + "\t" + Type.ToString() + "\t" + Amount.ToString("C");
        }
        public abstract decimal CalculationAmount
        { get; }
    }
    public class Check : Transaction
    {
        /// <summary>
        /// Check class to maintain Check Transaction data
        /// </summary>
        protected const decimal checkCharge = .10M;

        public Check (DateTime dateTime, string description, string category, decimal amount,
            string checknum) : base (dateTime, TransactionType.Check, description, category, amount, checknum)
        {

        }
        public override decimal CalculationAmount
        {
            get
            {
                return 0 - (Amount + checkCharge);
            }
        }
    }
    public class Debit : Transaction
    {
        /// <summary>
        /// Debit class to maintain Debit Transaction data
        /// </summary>
        public Debit (DateTime dateTime, string description, string category, decimal amount) :
            base (dateTime, TransactionType.Debit, description, category, amount)
        {

        }
        public override decimal CalculationAmount
        {
            get
            {
                return 0 - Amount;
            }
        }
    }
    public class Deposit : Transaction
    {
        /// <summary>
        /// Deposit class to maintain Deposit Transaction data
        /// </summary>
        public Deposit (DateTime dateTime, string description, string category, decimal amount) :
            base (dateTime, TransactionType.Deposit, description, category, amount)
        {

        }
        public override decimal CalculationAmount
        {
            get
            {
                return Amount;
            }
        }
    }
}
