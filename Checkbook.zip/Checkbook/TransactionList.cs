﻿// Checkbook - Final
// Jorge Montes - 3/7/2017
// Creating Client Applications in C#
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;   // Needed to inherit from ObservableCollection class
using System.Data.SqlClient;            // Needed to connect to SQLServer db

namespace Checkbook
{
    public class TransactionList : ObservableCollection<Transaction>
    {
        /// <summary>
        /// TransactionList class to store list of Transaction objects
        /// </summary>
        private bool ReadFromDatabase()
        {
            /// <summary>
            /// Helper method used to check if any records exist int the database
            /// </summary>
            /// <returns>Returns a true if records found, false if no records were found</returns>
            String connectionString = "Data Source=.;Initial Catalog=Checkbook;Integrated Security=True";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM CheckingTransaction", conn);
                try
                {
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        int id = (int)reader["TransactionId"];
                        int type = (int)reader["TransactionType"];
                        String category = (String)reader["Category"];
                        DateTime date = reader.GetDateTime(3);
                        String description = reader.GetString(4);
                        Decimal amount = reader.GetDecimal(5);
                        String checknum = reader.GetString(6);
                        switch ((TransactionType)type)
                        {
                            case TransactionType.Check:
                                Add(new Check(date, description, category, amount, checknum));
                                break;
                            case TransactionType.Debit:
                                Add(new Debit(date, description, category, amount));
                                break;
                            case TransactionType.Deposit:
                                Add(new Deposit(date, description, category, amount));
                                break;
                        }
                    }
                    reader.Close();

                }
                catch (SqlException e)
                {
                    Console.WriteLine("An exception occurred:" + e.Message);
                }
                return Count > 0;
            }
        }
        public TransactionList()
        {
            /// <summary>
            /// TransactionList constructor used to preload a few transactions from included XML string
            /// </summary>
            if (ReadFromDatabase())
            {
                return;
            }

            string XMLFile = "<Transactions><Transaction><Id>1</Id><Date>11/23/2014</Date><Type>Deposit</Type><Description>Pay</Description><Category>Income</Category><Amount>1327</Amount></Transaction><Transaction><Id>2</Id><Date>11/24/2014</Date><Type>Check</Type><Description>Food</Description><Category>Food</Category><Amount>62</Amount><Checknum>2021</Checknum></Transaction><Transaction><Id>3</Id><Date>11/24/2014</Date><Type>Debit</Type><Description>ATM</Description><Category>Misc</Category><Amount>40</Amount></Transaction><Transaction><Id>4</Id><Date>11/25/2014</Date><Type>Check</Type><Description>Rent</Description><Category>Rent</Category><Amount>713</Amount><Checknum>2022</Checknum></Transaction><Transaction><Id>5</Id><Date>11/26/2014</Date><Type>Debit</Type><Description>Dinner</Description><Category>Friends</Category><Amount>37.29</Amount></Transaction><Transaction><Id>6</Id><Date>11/26/2014</Date><Type>Debit</Type><Description>Movie</Description><Category>Friends</Category><Amount>12.50</Amount></Transaction><Transaction><Id>7</Id><Date>11/27/2014</Date><Type>Deposit</Type><Description>Mom</Description><Category>Income</Category><Amount>100</Amount></Transaction><Transaction><Id>8</Id><Date>11/28/2014</Date><Type>Check</Type><Description>Costco</Description><Category>Misc</Category><Amount>15.72</Amount><Checknum>2024</Checknum></Transaction><Transaction><Id>9</Id><Date>11/29/2014</Date><Type>Debit</Type><Description>Gas</Description><Category>Gas</Category><Amount>43.83</Amount></Transaction><Transaction><Id>10</Id><Date>11/30/2014</Date><Type>Debit</Type><Description>Market</Description><Category>Food</Category><Amount>35.11</Amount></Transaction></Transactions>";

                    Regex XMLPattern = new Regex(@"^(\<Transactions\>)(\<Transaction\>)(.*)(\<\/Transaction\>)(\<Transaction\>)(.*)(\<\/Transaction\>)(\<Transaction\>)(.*)(\<\/Transaction\>)(\<Transaction\>)(.*)(\<\/Transaction\>)(\<Transaction\>)(.*)(\<\/Transaction\>)(\<Transaction\>)(.*)(\<\/Transaction\>)(\<Transaction\>)(.*)(\<\/Transaction\>)(\<Transaction\>)(.*)(\<\/Transaction\>)(\<Transaction\>)(.*)(\<\/Transaction\>)(\<Transaction\>)(.*)(\<\/Transaction\>)(\<\/Transactions\>)$");
                    Match XMLMatch = XMLPattern.Match(XMLFile);

                    int i = 0;
                    while (i < 30)
                    {
                        i += 3;
                        Regex TransPattern = new Regex(@"^(\<Id\>)(.*)(\<\/Id\>)(\<Date\>)(.*)(\<\/Date\>)(\<Type\>)(.*)(\<\/Type\>)(\<Description\>)(.*)(\<\/Description\>)(\<Category\>)(.*)(\<\/Category\>)(\<Amount\>)(.*)(\<\/Amount\>)(\<Checknum\>)?(\d*)?(\<\/Checknum\>)?");

                        Match IdMatch = TransPattern.Match(XMLMatch.Groups[i].ToString());
                        Match DateMatch = TransPattern.Match(XMLMatch.Groups[i].ToString());
                        Match TypeMatch = TransPattern.Match(XMLMatch.Groups[i].ToString());
                        Match DescriptionMatch = TransPattern.Match(XMLMatch.Groups[i].ToString());
                        Match CategoryMatch = TransPattern.Match(XMLMatch.Groups[i].ToString());
                        Match AmountMatch = TransPattern.Match(XMLMatch.Groups[i].ToString());
                        Match ChecknumMatch = TransPattern.Match(XMLMatch.Groups[i].ToString());

                        // Cast amount to decimal
                        decimal amount = decimal.Parse(AmountMatch.Groups[17].ToString());

                        Transaction myTrans = null;
                        switch (TypeMatch.Groups[8].ToString())
                        {
                            case "Debit":
                                myTrans = new Debit(DateTime.Parse(DateMatch.Groups[5].ToString()), DescriptionMatch.Groups[11].ToString(),
                                    CategoryMatch.Groups[14].ToString(), amount);
                                break;
                            case "Deposit":
                                myTrans = new Deposit(DateTime.Parse(DateMatch.Groups[5].ToString()), DescriptionMatch.Groups[11].ToString(),
                                    CategoryMatch.Groups[14].ToString(), amount);
                                break;
                            case "Check":
                                myTrans = new Check(DateTime.Parse(DateMatch.Groups[5].ToString()), DescriptionMatch.Groups[11].ToString(),
                                    CategoryMatch.Groups[14].ToString(), amount, ChecknumMatch.Groups[20].ToString());
                                break;
                            default:
                                break;
                        }
                        Add(myTrans);
                    }
            String connectionString = "Data Source=.;Initial Catalog=Checkbook;Integrated Security=True";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    foreach (Transaction t in this)
                    {
                        SqlCommand cmd = new SqlCommand("INSERT INTO CheckingTransaction " + "(TransactionId, TransactionType, Category, TransactionDate, " + "Description, Amount, Checknum) values (" + t.Id + "," + (int)t.Type + ", '" + t.Category + "', '" + t.Date.ToShortDateString() + "','" + t.Description + "'," + t.Amount + ",'" + t.Checknum + "')", conn);
                        cmd.ExecuteNonQuery();
                    }
                }
                catch (SqlException e)
                {
                    Console.WriteLine("An exception occurred:" + e.Message);
                }
            }
        }

        public decimal Balance
        {
            /// <summary>
            /// Helper method used to calculate Balance for display
            /// </summary>
            get
            {
                decimal bal = 0;
                foreach (Transaction t in this)
                {
                    bal += t.CalculationAmount;
                }
                return bal;
            }
        }
    }
}
