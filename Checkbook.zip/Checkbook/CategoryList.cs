﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Checkbook
{
    public class CategoryList : List<Category>
    {
        TransactionList transactionList;
        public CategoryList(TransactionList tlTransactionList)
        {
            transactionList = tlTransactionList;
            Refresh();
        }
        public void AddTransaction(Transaction transaction)
        {
            foreach (Category c in this)
            {
                if (c.Title == transaction.Category)
                {
                    c.Amount += transaction.Amount;
                    return;
                }
            }
            Add(new Category(transaction.Category, transaction.Amount));
        }
        public void Refresh()
        {
            Clear();
            foreach (Transaction t in transactionList)
            {
                AddTransaction(t);
            }
            Sort();
        }
    }
}
