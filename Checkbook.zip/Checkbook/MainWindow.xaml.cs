﻿// Checkbook - Final
// Jorge Montes - 3/7/2017
// Creating Client Applications in C#
using System;
using System.Collections.Generic;
using System.Data.SqlClient;    // Needed to connect to SQLServer db
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Checkbook
{
    /// <summary>
    /// Checkbook class - Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        TransactionList transactionList = new TransactionList();
        CategoryList categoryList;

        public MainWindow()
        {
            InitializeComponent();
        }
        public TransactionList Transactions
        {
            get { return transactionList; }
            set { transactionList = value; }
        }

        private void Checkbook_Loaded(object sender, RoutedEventArgs e)
        {
            /// <summary>
            /// Handles transactionList and categoryList display objects.
            /// </summary>
            //lbTransactions.ItemsSource = transactionList;
            lblBalance.Content = transactionList.Balance.ToString("C");

            // Create category list
            categoryList = new CategoryList(transactionList);
            lbCategories.ItemsSource = categoryList;
        }

        private void lbTransactions_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            /// <summary>
            /// Used to display the corresponding transaction info in text boxes
            /// when a transaction in the transactionList is selected.
            /// </summary>
            if (lbTransactions.SelectedIndex < 0)
                lbTransactions.SelectedIndex = 0;
            int index = lbTransactions.SelectedIndex;
            if (index >= 0)
            {
                Transaction tr = transactionList[index];
                textBox_ID.Text = tr.Id.ToString();
                textBox_Type.Text = tr.Type.ToString();
                textBox_Desc.Text = tr.Description.ToString();
                textBox_Date.Text = tr.Date.ToShortDateString();
                label_AmtVerb.Content = tr.AmountString;
                textBox_Amount.Text = tr.Amount.ToString("C");
                textBox_Category.Text = tr.Category;
                textBox_CheckNum.Text = tr.Checknum;
            }
        }

        private void button_Edit_Click(object sender, RoutedEventArgs e)
        {
            /// <summary>
            /// Used to add a transaction.  Launches dialog box to enter transaction information.
            /// </summary>
            int index = lbTransactions.SelectedIndex;
            Transaction selectedTrans = transactionList[index];

            EditTransaction editTr = new EditTransaction(selectedTrans);
            bool action = (bool)editTr.ShowDialog();
            if (action == true)
            {
                // Update transaction contents
                selectedTrans.Description = editTr.textBox_Desc.Text;
                selectedTrans.Amount = decimal.Parse(editTr.textBox_Amount.Text.ToString());
                selectedTrans.Category = editTr.comboBox_Category.Text;
                selectedTrans.Checknum = editTr.textBox_Checknum.Text;
                // Update original trnsaction object
                transactionList[index] = selectedTrans;

                // Update the record in the database
                using (SqlConnection connection = new SqlConnection("Data Source=.;Initial Catalog=Checkbook;Integrated Security=True"))
                {
                    try
                    {
                        string sql = "UPDATE CheckingTransaction SET CheckNum=@checknum, Category=@category, Description=@description, Amount=@amount, TransactionDate=@date WHERE TransactionId=@id";

                        SqlCommand command = new SqlCommand(sql, connection);

                        command.Parameters.AddWithValue("id", editTr.textBox_ID.Text);
                        command.Parameters.AddWithValue("checknum", editTr.textBox_Checknum.Text);
                        command.Parameters.AddWithValue("category", editTr.textBox_Type.Text);
                        command.Parameters.AddWithValue("description", editTr.textBox_Desc.Text);
                        command.Parameters.AddWithValue("amount", (object)editTr.textBox_Amount.Text);
                        command.Parameters.AddWithValue("date", editTr.textBox_Date.Text);

                        connection.Open();
                        command.ExecuteNonQuery();
                    }
                    catch (SqlException err)
                    {
                        Console.WriteLine("An exception occurred:" + err.Message);
                    }
                }

                // Refresh Transactions ListBox
                lbTransactions.ItemsSource = null;
                lbTransactions.ItemsSource = transactionList;
                lblBalance.Content = transactionList.Balance.ToString("C");

                // Refresh Category ListBox
                categoryList = null;
                categoryList = new CategoryList(transactionList);
                lbCategories.ItemsSource = null;
                lbCategories.ItemsSource = categoryList;
            }
        }
    }
}
