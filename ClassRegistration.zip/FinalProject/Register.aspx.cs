﻿// Creating Web Applications in C#
// Final Project
// Jorge Montes - 6/13/2017

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using FinalProject.App_Code;

namespace FinalProject
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        // Registers student for classes.
        // Re-uses Classes class to display available classes, and
        // calls Register class to register student for classes.

        int studentId = 0;
        int rowsAffected;

        protected void Page_Load(object sender, EventArgs e)
        {
            // If no session Id exists, then user is not logged in.
            // If not logged in, send them to Login screen.

            if (Session["StudentId"] != null)
            {
                studentId = Int32.Parse(Session["StudentId"].ToString());
            }
            else
            {
                Response.Redirect("~/Login.aspx");
            }

            if (!IsPostBack)
            {
                // RE-USE Classes.cs, also used for Classes screen

                // Obtain DataSet and data
                System.Data.DataSet outDataSet;
                Classes objClasses = new Classes(out outDataSet);

                // Populate the gridView with our DataSet
                gridViewClasses.DataSource = outDataSet;
                gridViewClasses.DataBind();
            }
        }

        protected void gridViewClasses_SelectedIndexChanged(object sender, EventArgs e)
        {
            LabelRegistered.Text = "<p>" + gridViewClasses.SelectedRow.Cells[2].Text + "</p>";
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            // Initialize counters
            int classesSelected = 0;
            int classesRegistered = 0;

            // Iterate through gridView, and call Register class for each row checked
            foreach (GridViewRow row in gridViewClasses.Rows)
            {
                CheckBox check = (CheckBox)row.FindControl("CheckBox1");

                if (check.Checked)
                {
                    classesSelected++;
                    Register.ExecRegister(studentId, Int32.Parse(row.Cells[1].Text), out rowsAffected);
                    if (rowsAffected != 0)
                    { classesRegistered++; }
                }
            }
            // Success/fail message
            if (classesSelected > 0 && classesRegistered == classesSelected)
            { LabelRegistered.Text = "Thank you! You have been registered in the classes selected."; }
            else
            { LabelRegistered.Text = "An error occurred while submitting your request. Please call your administrator."; }
        }
    }
}