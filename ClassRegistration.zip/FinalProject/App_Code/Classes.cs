﻿// Creating Web Applications in C#
// Final Project
// Jorge Montes - 6/13/2017

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace FinalProject.App_Code
{
    public class Classes
    {
        // Class returns all records from Classes table; reads from a db view

        public Classes(out System.Data.DataSet outDataSet)
        {
            ExecClasses(out outDataSet);
        }

        public void ExecClasses(out System.Data.DataSet outDataSet)
        {
            // Var and DataSet Definitions
            string dummyVar = "";
            System.Data.DataSet ds = new System.Data.DataSet();

            // Create Connection object
            System.Data.OleDb.OleDbConnection objOleCon = new System.Data.OleDb.OleDbConnection();
            objOleCon.ConnectionString = ConfigurationManager.ConnectionStrings["AdvWebDevProject"].ConnectionString;
            using (objOleCon)
            {
                try
                {
                    // Issue a Command via Adapter
                    System.Data.OleDb.OleDbDataAdapter adp =
                        new System.Data.OleDb.OleDbDataAdapter(@"SELECT * FROM dbo.vClasses;", objOleCon);

                    // Open Connection and obtain the DataSet
                    objOleCon.Open();
                    adp.Fill(ds);
                    outDataSet = ds;
                }
                catch (System.Data.OleDb.OleDbException err)
                { dummyVar = err.Message; }
                finally
                {
                    // Free up resources
                    objOleCon.Close();
                }
                outDataSet = ds;
            }
        }
    }
}