﻿// Creating Web Applications in C#
// Final Project
// Jorge Montes - 6/13/2017

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace FinalProject.App_Code
{
    public class LoginRequests
    {
        // Class creates a login request record, requesting access for user

        public LoginRequests(string name, string emailAddress, string loginName, string newOrReactivate,
            string reasonForAccess, DateTime dateNeededBy, out int outRowsAffected)
        {
            CreateLoginReq(name, emailAddress, loginName, newOrReactivate, reasonForAccess, dateNeededBy,
                out outRowsAffected);
        }

        public void CreateLoginReq(string name, string emailAddress, string loginName, string newOrReactivate, 
            string reasonForAccess, DateTime dateNeededBy, out int outRowsAffected)
        {
            outRowsAffected = 0;

            // Create Connection object
            System.Data.OleDb.OleDbConnection objOleCon = new System.Data.OleDb.OleDbConnection();
            objOleCon.ConnectionString = ConfigurationManager.ConnectionStrings["AdvWebDevProject"].ConnectionString;
            using (objOleCon)
            {
                try
                {
                    // Issue a Command
                    System.Data.OleDb.OleDbCommand objCmd = new System.Data.OleDb.OleDbCommand("pInsLoginRequest", objOleCon);
                    objCmd.CommandType = System.Data.CommandType.StoredProcedure;

                    // Add Parameters
                    System.Data.OleDb.OleDbParameter objName = new System.Data.OleDb.OleDbParameter("@Name", System.Data.OleDb.OleDbType.VarWChar, 50);
                    objName.Direction = System.Data.ParameterDirection.Input;
                    objName.Value = name;
                    objCmd.Parameters.Add(objName);

                    System.Data.OleDb.OleDbParameter objEmailAddress = new System.Data.OleDb.OleDbParameter("@EmailAddress", System.Data.OleDb.OleDbType.VarWChar, 50);
                    objEmailAddress.Direction = System.Data.ParameterDirection.Input;
                    objEmailAddress.Value = emailAddress;
                    objCmd.Parameters.Add(objEmailAddress);

                    System.Data.OleDb.OleDbParameter objLoginName = new System.Data.OleDb.OleDbParameter("@LoginName", System.Data.OleDb.OleDbType.VarWChar, 50);
                    objLoginName.Direction = System.Data.ParameterDirection.Input;
                    objLoginName.Value = loginName;
                    objCmd.Parameters.Add(objLoginName);

                    System.Data.OleDb.OleDbParameter objNewOrReactivate = new System.Data.OleDb.OleDbParameter("@NewOrReactivate", System.Data.OleDb.OleDbType.VarWChar, 50);
                    objNewOrReactivate.Direction = System.Data.ParameterDirection.Input;
                    objNewOrReactivate.Value = newOrReactivate;
                    objCmd.Parameters.Add(objNewOrReactivate);

                    System.Data.OleDb.OleDbParameter objReasonForAccess = new System.Data.OleDb.OleDbParameter("@ReasonForAccess", System.Data.OleDb.OleDbType.VarWChar, 50);
                    objReasonForAccess.Direction = System.Data.ParameterDirection.Input;
                    objReasonForAccess.Value = reasonForAccess;
                    objCmd.Parameters.Add(objReasonForAccess);

                    System.Data.OleDb.OleDbParameter objDateNeededBy = new System.Data.OleDb.OleDbParameter("@DateNeededBy", System.Data.OleDb.OleDbType.Date);
                    objDateNeededBy.Direction = System.Data.ParameterDirection.Input;
                    objDateNeededBy.Value = dateNeededBy;
                    objCmd.Parameters.Add(objDateNeededBy);

                    // Open Connection and Execute the code
                    objOleCon.Open();
                    outRowsAffected = objCmd.ExecuteNonQuery();
                }
                catch (System.Data.OleDb.OleDbException err)
                { return; }
                finally
                {
                    // Free up resources
                    objOleCon.Close();
                }
            }
        }

    }
}