﻿// Creating Web Applications in C#
// Final Project
// Jorge Montes - 6/13/2017

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace FinalProject.App_Code
{
    public class Register
    {
        // Class facilitates for a student to register for classes

        public Register() { }
        public Register(int studentId, int classId, out int outRowsAffected)
        {
            ExecRegister(studentId, classId, out outRowsAffected);
        }

        public static void ExecRegister(int studentId, int classId, out int outRowsAffected)
        {
            outRowsAffected = 0;
            
            // Create Connection object
            System.Data.OleDb.OleDbConnection objOleCon = new System.Data.OleDb.OleDbConnection();
            objOleCon.ConnectionString = ConfigurationManager.ConnectionStrings["AdvWebDevProject"].ConnectionString;
            using (objOleCon)
            {
                try
                {
                    // Issue a Command
                    System.Data.OleDb.OleDbCommand objCmd = new System.Data.OleDb.OleDbCommand("pInsClassStudents", objOleCon);
                    objCmd.CommandType = System.Data.CommandType.StoredProcedure;

                    // Add Parameters
                    System.Data.OleDb.OleDbParameter objClassId;
                    objClassId = new System.Data.OleDb.OleDbParameter("@ClassId", System.Data.OleDb.OleDbType.Integer);
                    objClassId.Direction = System.Data.ParameterDirection.Input;
                    objClassId.Value = classId;
                    objCmd.Parameters.Add(objClassId);

                    System.Data.OleDb.OleDbParameter objStudentId;
                    objStudentId = new System.Data.OleDb.OleDbParameter("@StudentId", System.Data.OleDb.OleDbType.Integer);
                    objStudentId.Direction = System.Data.ParameterDirection.Input;
                    objStudentId.Value = studentId;
                    objCmd.Parameters.Add(objStudentId);

                    // Open Connection and Execute the code
                    objOleCon.Open();
                    outRowsAffected = objCmd.ExecuteNonQuery();
                }
                catch (System.Data.OleDb.OleDbException err)
                { return; }
                finally
                {
                    // Free up resources
                    objOleCon.Close();
                }
            }
        }
    }
}