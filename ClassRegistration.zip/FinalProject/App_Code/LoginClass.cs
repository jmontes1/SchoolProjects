﻿// Creating Web Applications in C#
// Final Project
// Jorge Montes - 6/13/2017

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace FinalProject.App_Code
{
    public class LoginClass
    {
        // Class facilitates for the user to login to database; reads from a db view

        public LoginClass(string loginId, string password, out string outStudentId)
        {
            ExecLogin(loginId, password, out outStudentId);
        }

        public void ExecLogin(string loginId, string password, out string outStudentId)
        {
            outStudentId = string.Empty;

            // Create Connection object
            System.Data.OleDb.OleDbConnection objOleCon = new System.Data.OleDb.OleDbConnection();
            objOleCon.ConnectionString = ConfigurationManager.ConnectionStrings["AdvWebDevProject"].ConnectionString;
            using (objOleCon)
            {
                try
                {
                    // Issue a Command
                    System.Data.OleDb.OleDbCommand objCmd = new System.Data.OleDb.OleDbCommand("pSelLoginIdByLoginAndPassword", objOleCon);
                    objCmd.CommandType = System.Data.CommandType.StoredProcedure;

                    // Add Parameters
                    System.Data.OleDb.OleDbParameter objStudentLogin;
                    objStudentLogin = new System.Data.OleDb.OleDbParameter("@StudentLogin", System.Data.OleDb.OleDbType.VarWChar, 50);
                    objStudentLogin.Direction = System.Data.ParameterDirection.Input;
                    objStudentLogin.Value = loginId;
                    objCmd.Parameters.Add(objStudentLogin);

                    System.Data.OleDb.OleDbParameter objStudentPassword;
                    objStudentPassword = new System.Data.OleDb.OleDbParameter("@StudentPassword", System.Data.OleDb.OleDbType.VarWChar, 50);
                    objStudentPassword.Direction = System.Data.ParameterDirection.Input;
                    objStudentPassword.Value = password;
                    objCmd.Parameters.Add(objStudentPassword);

                    System.Data.OleDb.OleDbParameter objStudentId;
                    objStudentId = new System.Data.OleDb.OleDbParameter("@StudentId", System.Data.OleDb.OleDbType.Integer);
                    objStudentId.Direction = System.Data.ParameterDirection.Output;
                    objStudentId.DbType = System.Data.DbType.Int32;
                    objCmd.Parameters.Add(objStudentId);

                    // Open Connection and Execute the code
                    objOleCon.Open();
                    objCmd.ExecuteNonQuery();
                    outStudentId = objCmd.Parameters["@StudentId"].Value.ToString();
                }
                catch (System.Data.OleDb.OleDbException err)
                { return; }
                finally
                {
                    // Free up resources
                    objOleCon.Close();
                }
            }
        }
    }
}