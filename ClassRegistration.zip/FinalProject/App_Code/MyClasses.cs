﻿// Creating Web Applications in C#
// Final Project
// Jorge Montes - 6/13/2017

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace FinalProject.App_Code
{
    public class MyClasses
    {
        // Class returns all records for which a student is registered

        public MyClasses(int studentId, out System.Data.DataSet outDataSet)
        {
            ExecMyClasses(studentId, out outDataSet);
        }

        public void ExecMyClasses(int studentId, out System.Data.DataSet outDataSet)
        {
            // Var and DataSet Definitions
            string dummyVar = "";
            System.Data.DataSet ds = new System.Data.DataSet();

            // Create Connection object
            System.Data.OleDb.OleDbConnection objOleCon = new System.Data.OleDb.OleDbConnection();
            objOleCon.ConnectionString = ConfigurationManager.ConnectionStrings["AdvWebDevProject"].ConnectionString;
            using (objOleCon)
            {
                try
                {
                    // Issue a Command
                    System.Data.OleDb.OleDbCommand objCmd;
                    objCmd = new System.Data.OleDb.OleDbCommand("pSelClassesByStudentID", objOleCon);
                    objCmd.CommandType = System.Data.CommandType.StoredProcedure;

                    // Add parameter
                    System.Data.OleDb.OleDbParameter objStudentId = new System.Data.OleDb.OleDbParameter("@StudentId", System.Data.OleDb.OleDbType.Integer);
                    objStudentId.Direction = System.Data.ParameterDirection.Input;
                    objStudentId.Value = studentId;
                    objCmd.Parameters.Add(objStudentId);

                    // Create Adapter
                    System.Data.OleDb.OleDbDataAdapter adp =
                        new System.Data.OleDb.OleDbDataAdapter(objCmd);

                    // Open Connection and obtain the DataSet
                    objOleCon.Open();
                    adp.Fill(ds);
                    outDataSet = ds;
                }
                catch (System.Data.OleDb.OleDbException err)
                { dummyVar = err.Message; }
                finally
                {
                    // Free up resources
                    objOleCon.Close();
                }
                outDataSet = ds;
            }
        }
    }
}