﻿// Creating Web Applications in C#
// Final Project
// Jorge Montes - 6/13/2017

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using FinalProject.App_Code;

namespace FinalProject
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        // Creates a login request record, requesting access for user by
        // calling a method in LoginRequests class.

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void SubmitReq(object sender, EventArgs e)
        {
            // Send login request info to LoginRequests class
            int rowsAffected;
            LoginRequests objLoginRequests = new LoginRequests(TextboxName.Text, TextboxEmailAddr.Text,
                TextboxLoginName.Text, RadioNewOrReactivate.SelectedValue, TextboxReason4Access.Text, 
                Convert.ToDateTime(TextboxDateNeedBy.Text), out rowsAffected);

            // Success/fail message
            if (rowsAffected != 0)
            { LabelSubmitted.Text = "Thank you! Someone will contact you after processing your request."; }
            else
            { LabelSubmitted.Text = "An error occurred while submitting your request. Please call your administrator."; }
        }
    }
}