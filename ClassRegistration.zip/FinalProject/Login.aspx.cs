﻿// Creating Web Applications in C#
// Final Project
// Jorge Montes - 6/13/2017

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using FinalProject.App_Code;

namespace FinalProject
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        // Logs user into database by calling LoginClass to obtain Student Id.
        // If found in database, user's Student Id is used as the session id.

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            // Send credentials to LoginClass class
            string studentId;
            LoginClass objLogin = new LoginClass(tbLoginId.Text, tbPassword.Text, out studentId);

            // Login success or failure -- Set the session Id
            if (studentId != "")
            {
                Session["StudentId"] = studentId;
                LabelLoggedIn.Text = "Welcome! You are logged in.";
            }
            else { LabelLoggedIn.Text = "Invalid credentials or an error occurred. Please call your administrator."; }
        }
    }
}