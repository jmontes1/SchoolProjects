﻿// Creating Web Applications in C#
// Final Project
// Jorge Montes - 6/13/2017

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using FinalProject.App_Code;

namespace FinalProject
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        // Displays all Classes for which a user is registered.
        // Calls method in MyClasses class to obtain DataSet.

        protected void Page_Load(object sender, EventArgs e)
        {
            // If no session Id exists, then user is not logged in.
            // If not logged in, send them to Login screen.

            int studentId = 0;

            if (Session["StudentId"] != null)
            {
                studentId = Int32.Parse(Session["StudentId"].ToString());
            }
            else
            {
                Response.Redirect("~/Login.aspx");
            }

            if (!IsPostBack)
            {
                // Obtain DataSet and data
                System.Data.DataSet outDataSet;
                MyClasses objMyClasses = new MyClasses(studentId, out outDataSet);

                // Populate the gridView with our DataSet
                gridViewMyClasses.DataSource = outDataSet;
                gridViewMyClasses.DataBind();
            }
        }
    }
}