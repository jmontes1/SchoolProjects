﻿// Creating Web Applications in C#
// Final Project
// Jorge Montes - 6/13/2017

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using FinalProject.App_Code;

namespace FinalProject
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        // Displays all records from Classes table by using a gridView.
        // Calls method in Classes class to obtain DataSet.

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Obtain DataSet and data
                System.Data.DataSet outDataSet;
                Classes objClasses = new Classes(out outDataSet);

                // Populate the gridView with our DataSet
                gridViewClasses.DataSource = outDataSet;
                gridViewClasses.DataBind();
            }
        }
    }
}