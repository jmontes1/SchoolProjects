﻿namespace Exercise08
{
    partial class FormVendMachine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormVendMachine));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btn_RefillRack = new System.Windows.Forms.Button();
            this.listViewCanRack = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBoxCanRack = new System.Windows.Forms.GroupBox();
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listViewVMCoinBox = new System.Windows.Forms.ListView();
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btn_EmptyTransBox = new System.Windows.Forms.Button();
            this.btn_EmptyVMBox = new System.Windows.Forms.Button();
            this.listViewTransBox = new System.Windows.Forms.ListView();
            this.groupBoxVMBox = new System.Windows.Forms.GroupBox();
            this.tabVend = new System.Windows.Forms.TabPage();
            this.btn_Nickel = new System.Windows.Forms.Button();
            this.btn_Dime = new System.Windows.Forms.Button();
            this.btn_Quarter = new System.Windows.Forms.Button();
            this.btn_HalfDollar = new System.Windows.Forms.Button();
            this.btn_Lemon = new System.Windows.Forms.Button();
            this.btn_Orange = new System.Windows.Forms.Button();
            this.btn_Regular = new System.Windows.Forms.Button();
            this.btn_CoinReturn = new System.Windows.Forms.Button();
            this.pictureBoxLemon = new System.Windows.Forms.PictureBox();
            this.pictureBoxOrange = new System.Windows.Forms.PictureBox();
            this.pictureBoxRegular = new System.Windows.Forms.PictureBox();
            this.labelAmtEntered = new System.Windows.Forms.Label();
            this.labelExactChange = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabService = new System.Windows.Forms.TabPage();
            this.btn_SvcNotes = new System.Windows.Forms.Button();
            this.groupBoxCanRack.SuspendLayout();
            this.groupBoxVMBox.SuspendLayout();
            this.tabVend.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLemon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOrange)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRegular)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabService.SuspendLayout();
            this.SuspendLayout();
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "# of Cans Left";
            this.columnHeader2.Width = 83;
            // 
            // btn_RefillRack
            // 
            this.btn_RefillRack.Location = new System.Drawing.Point(75, 166);
            this.btn_RefillRack.Name = "btn_RefillRack";
            this.btn_RefillRack.Size = new System.Drawing.Size(75, 23);
            this.btn_RefillRack.TabIndex = 1;
            this.btn_RefillRack.Text = "Refill Rack";
            this.btn_RefillRack.UseVisualStyleBackColor = true;
            this.btn_RefillRack.Click += new System.EventHandler(this.btn_RefillRack_Click);
            // 
            // listViewCanRack
            // 
            this.listViewCanRack.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.listViewCanRack.GridLines = true;
            this.listViewCanRack.Location = new System.Drawing.Point(6, 19);
            this.listViewCanRack.Name = "listViewCanRack";
            this.listViewCanRack.Size = new System.Drawing.Size(203, 130);
            this.listViewCanRack.TabIndex = 0;
            this.listViewCanRack.UseCompatibleStateImageBehavior = false;
            this.listViewCanRack.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Flavor";
            this.columnHeader1.Width = 114;
            // 
            // groupBoxCanRack
            // 
            this.groupBoxCanRack.Controls.Add(this.btn_RefillRack);
            this.groupBoxCanRack.Controls.Add(this.listViewCanRack);
            this.groupBoxCanRack.Location = new System.Drawing.Point(7, 7);
            this.groupBoxCanRack.Name = "groupBoxCanRack";
            this.groupBoxCanRack.Size = new System.Drawing.Size(214, 201);
            this.groupBoxCanRack.TabIndex = 1;
            this.groupBoxCanRack.TabStop = false;
            this.groupBoxCanRack.Text = "Can Rack";
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Value";
            this.columnHeader5.Width = 72;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "# of Coins";
            this.columnHeader4.Width = 61;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "VM Box-Type Of Coin";
            this.columnHeader3.Width = 123;
            // 
            // listViewVMCoinBox
            // 
            this.listViewVMCoinBox.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.listViewVMCoinBox.GridLines = true;
            this.listViewVMCoinBox.Location = new System.Drawing.Point(6, 19);
            this.listViewVMCoinBox.Name = "listViewVMCoinBox";
            this.listViewVMCoinBox.Size = new System.Drawing.Size(260, 130);
            this.listViewVMCoinBox.TabIndex = 0;
            this.listViewVMCoinBox.UseCompatibleStateImageBehavior = false;
            this.listViewVMCoinBox.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Value";
            this.columnHeader8.Width = 72;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "# of Coins";
            this.columnHeader7.Width = 61;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Type of Coin";
            this.columnHeader6.Width = 123;
            // 
            // btn_EmptyTransBox
            // 
            this.btn_EmptyTransBox.Location = new System.Drawing.Point(74, 358);
            this.btn_EmptyTransBox.Name = "btn_EmptyTransBox";
            this.btn_EmptyTransBox.Size = new System.Drawing.Size(118, 23);
            this.btn_EmptyTransBox.TabIndex = 3;
            this.btn_EmptyTransBox.Text = "Empty Trans Box";
            this.btn_EmptyTransBox.UseVisualStyleBackColor = true;
            this.btn_EmptyTransBox.Click += new System.EventHandler(this.btn_EmptyTransBox_Click);
            // 
            // btn_EmptyVMBox
            // 
            this.btn_EmptyVMBox.Location = new System.Drawing.Point(74, 155);
            this.btn_EmptyVMBox.Name = "btn_EmptyVMBox";
            this.btn_EmptyVMBox.Size = new System.Drawing.Size(118, 23);
            this.btn_EmptyVMBox.TabIndex = 2;
            this.btn_EmptyVMBox.Text = "Empty Vend Coin Box";
            this.btn_EmptyVMBox.UseVisualStyleBackColor = true;
            this.btn_EmptyVMBox.Click += new System.EventHandler(this.btn_EmptyVMBox_Click);
            // 
            // listViewTransBox
            // 
            this.listViewTransBox.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8});
            this.listViewTransBox.GridLines = true;
            this.listViewTransBox.Location = new System.Drawing.Point(6, 196);
            this.listViewTransBox.Name = "listViewTransBox";
            this.listViewTransBox.Size = new System.Drawing.Size(260, 155);
            this.listViewTransBox.TabIndex = 1;
            this.listViewTransBox.UseCompatibleStateImageBehavior = false;
            this.listViewTransBox.View = System.Windows.Forms.View.Details;
            // 
            // groupBoxVMBox
            // 
            this.groupBoxVMBox.Controls.Add(this.btn_EmptyTransBox);
            this.groupBoxVMBox.Controls.Add(this.btn_EmptyVMBox);
            this.groupBoxVMBox.Controls.Add(this.listViewTransBox);
            this.groupBoxVMBox.Controls.Add(this.listViewVMCoinBox);
            this.groupBoxVMBox.Location = new System.Drawing.Point(236, 7);
            this.groupBoxVMBox.Name = "groupBoxVMBox";
            this.groupBoxVMBox.Size = new System.Drawing.Size(278, 391);
            this.groupBoxVMBox.TabIndex = 2;
            this.groupBoxVMBox.TabStop = false;
            this.groupBoxVMBox.Text = "Coin Boxes";
            // 
            // tabVend
            // 
            this.tabVend.Controls.Add(this.btn_Nickel);
            this.tabVend.Controls.Add(this.btn_Dime);
            this.tabVend.Controls.Add(this.btn_Quarter);
            this.tabVend.Controls.Add(this.btn_HalfDollar);
            this.tabVend.Controls.Add(this.btn_Lemon);
            this.tabVend.Controls.Add(this.btn_Orange);
            this.tabVend.Controls.Add(this.btn_Regular);
            this.tabVend.Controls.Add(this.btn_CoinReturn);
            this.tabVend.Controls.Add(this.pictureBoxLemon);
            this.tabVend.Controls.Add(this.pictureBoxOrange);
            this.tabVend.Controls.Add(this.pictureBoxRegular);
            this.tabVend.Controls.Add(this.labelAmtEntered);
            this.tabVend.Controls.Add(this.labelExactChange);
            this.tabVend.Controls.Add(this.label1);
            this.tabVend.Location = new System.Drawing.Point(4, 22);
            this.tabVend.Name = "tabVend";
            this.tabVend.Padding = new System.Windows.Forms.Padding(3);
            this.tabVend.Size = new System.Drawing.Size(522, 404);
            this.tabVend.TabIndex = 0;
            this.tabVend.Text = "Vend";
            this.tabVend.UseVisualStyleBackColor = true;
            // 
            // btn_Nickel
            // 
            this.btn_Nickel.Location = new System.Drawing.Point(294, 344);
            this.btn_Nickel.Name = "btn_Nickel";
            this.btn_Nickel.Size = new System.Drawing.Size(75, 23);
            this.btn_Nickel.TabIndex = 27;
            this.btn_Nickel.Text = "Nickel";
            this.btn_Nickel.UseVisualStyleBackColor = true;
            this.btn_Nickel.Click += new System.EventHandler(this.btn_Nickel_Click);
            // 
            // btn_Dime
            // 
            this.btn_Dime.Location = new System.Drawing.Point(294, 315);
            this.btn_Dime.Name = "btn_Dime";
            this.btn_Dime.Size = new System.Drawing.Size(75, 23);
            this.btn_Dime.TabIndex = 26;
            this.btn_Dime.Text = "Dime";
            this.btn_Dime.UseVisualStyleBackColor = true;
            this.btn_Dime.Click += new System.EventHandler(this.btn_Dime_Click);
            // 
            // btn_Quarter
            // 
            this.btn_Quarter.Location = new System.Drawing.Point(213, 344);
            this.btn_Quarter.Name = "btn_Quarter";
            this.btn_Quarter.Size = new System.Drawing.Size(75, 23);
            this.btn_Quarter.TabIndex = 25;
            this.btn_Quarter.Text = "Quarter";
            this.btn_Quarter.UseVisualStyleBackColor = true;
            this.btn_Quarter.Click += new System.EventHandler(this.btn_Quarter_Click);
            // 
            // btn_HalfDollar
            // 
            this.btn_HalfDollar.Location = new System.Drawing.Point(213, 315);
            this.btn_HalfDollar.Name = "btn_HalfDollar";
            this.btn_HalfDollar.Size = new System.Drawing.Size(75, 23);
            this.btn_HalfDollar.TabIndex = 24;
            this.btn_HalfDollar.Text = "Half Dollar";
            this.btn_HalfDollar.UseVisualStyleBackColor = true;
            this.btn_HalfDollar.Click += new System.EventHandler(this.btn_HalfDollar_Click);
            // 
            // btn_Lemon
            // 
            this.btn_Lemon.Enabled = false;
            this.btn_Lemon.Location = new System.Drawing.Point(383, 212);
            this.btn_Lemon.Name = "btn_Lemon";
            this.btn_Lemon.Size = new System.Drawing.Size(75, 23);
            this.btn_Lemon.TabIndex = 23;
            this.btn_Lemon.Text = "Lemon";
            this.btn_Lemon.UseVisualStyleBackColor = true;
            this.btn_Lemon.Click += new System.EventHandler(this.btn_Lemon_Click);
            // 
            // btn_Orange
            // 
            this.btn_Orange.Enabled = false;
            this.btn_Orange.Location = new System.Drawing.Point(219, 212);
            this.btn_Orange.Name = "btn_Orange";
            this.btn_Orange.Size = new System.Drawing.Size(75, 23);
            this.btn_Orange.TabIndex = 22;
            this.btn_Orange.Text = "Orange";
            this.btn_Orange.UseVisualStyleBackColor = true;
            this.btn_Orange.Click += new System.EventHandler(this.btn_Orange_Click);
            // 
            // btn_Regular
            // 
            this.btn_Regular.Enabled = false;
            this.btn_Regular.Location = new System.Drawing.Point(60, 212);
            this.btn_Regular.Name = "btn_Regular";
            this.btn_Regular.Size = new System.Drawing.Size(75, 23);
            this.btn_Regular.TabIndex = 21;
            this.btn_Regular.Text = "Regular";
            this.btn_Regular.UseVisualStyleBackColor = true;
            this.btn_Regular.Click += new System.EventHandler(this.btn_Regular_Click);
            // 
            // btn_CoinReturn
            // 
            this.btn_CoinReturn.Enabled = false;
            this.btn_CoinReturn.Location = new System.Drawing.Point(383, 344);
            this.btn_CoinReturn.Name = "btn_CoinReturn";
            this.btn_CoinReturn.Size = new System.Drawing.Size(75, 23);
            this.btn_CoinReturn.TabIndex = 20;
            this.btn_CoinReturn.Text = "Coin Return";
            this.btn_CoinReturn.UseVisualStyleBackColor = true;
            this.btn_CoinReturn.Click += new System.EventHandler(this.btn_CoinReturn_Click);
            // 
            // pictureBoxLemon
            // 
            this.pictureBoxLemon.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLemon.Image")));
            this.pictureBoxLemon.Location = new System.Drawing.Point(342, 77);
            this.pictureBoxLemon.Name = "pictureBoxLemon";
            this.pictureBoxLemon.Size = new System.Drawing.Size(137, 116);
            this.pictureBoxLemon.TabIndex = 19;
            this.pictureBoxLemon.TabStop = false;
            // 
            // pictureBoxOrange
            // 
            this.pictureBoxOrange.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxOrange.Image")));
            this.pictureBoxOrange.Location = new System.Drawing.Point(178, 77);
            this.pictureBoxOrange.Name = "pictureBoxOrange";
            this.pictureBoxOrange.Size = new System.Drawing.Size(132, 116);
            this.pictureBoxOrange.TabIndex = 18;
            this.pictureBoxOrange.TabStop = false;
            // 
            // pictureBoxRegular
            // 
            this.pictureBoxRegular.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxRegular.Image")));
            this.pictureBoxRegular.Location = new System.Drawing.Point(19, 77);
            this.pictureBoxRegular.Name = "pictureBoxRegular";
            this.pictureBoxRegular.Size = new System.Drawing.Size(126, 116);
            this.pictureBoxRegular.TabIndex = 17;
            this.pictureBoxRegular.TabStop = false;
            // 
            // labelAmtEntered
            // 
            this.labelAmtEntered.AutoSize = true;
            this.labelAmtEntered.Location = new System.Drawing.Point(291, 288);
            this.labelAmtEntered.Name = "labelAmtEntered";
            this.labelAmtEntered.Size = new System.Drawing.Size(86, 13);
            this.labelAmtEntered.TabIndex = 16;
            this.labelAmtEntered.Text = "Amount Entered:";
            // 
            // labelExactChange
            // 
            this.labelExactChange.AutoSize = true;
            this.labelExactChange.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelExactChange.ForeColor = System.Drawing.Color.Red;
            this.labelExactChange.Location = new System.Drawing.Point(316, 259);
            this.labelExactChange.Name = "labelExactChange";
            this.labelExactChange.Size = new System.Drawing.Size(142, 15);
            this.labelExactChange.TabIndex = 15;
            this.labelExactChange.Text = "Exact change is required";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(120, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(288, 20);
            this.label1.TabIndex = 14;
            this.label1.Text = "Please insert 35 cents for a can of soda";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabVend);
            this.tabControl1.Controls.Add(this.tabService);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(530, 430);
            this.tabControl1.TabIndex = 1;
            // 
            // tabService
            // 
            this.tabService.Controls.Add(this.btn_SvcNotes);
            this.tabService.Controls.Add(this.groupBoxVMBox);
            this.tabService.Controls.Add(this.groupBoxCanRack);
            this.tabService.Location = new System.Drawing.Point(4, 22);
            this.tabService.Name = "tabService";
            this.tabService.Padding = new System.Windows.Forms.Padding(3);
            this.tabService.Size = new System.Drawing.Size(522, 404);
            this.tabService.TabIndex = 1;
            this.tabService.Text = "Service";
            this.tabService.UseVisualStyleBackColor = true;
            // 
            // btn_SvcNotes
            // 
            this.btn_SvcNotes.Location = new System.Drawing.Point(67, 262);
            this.btn_SvcNotes.Name = "btn_SvcNotes";
            this.btn_SvcNotes.Size = new System.Drawing.Size(90, 23);
            this.btn_SvcNotes.TabIndex = 3;
            this.btn_SvcNotes.Text = "Service Notes";
            this.btn_SvcNotes.UseVisualStyleBackColor = true;
            this.btn_SvcNotes.Click += new System.EventHandler(this.btn_SvcNotes_Click);
            // 
            // FormVendMachine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(552, 451);
            this.Controls.Add(this.tabControl1);
            this.Name = "FormVendMachine";
            this.Text = "Vending Machine";
            this.Load += new System.EventHandler(this.FormVendMachine_Load);
            this.groupBoxCanRack.ResumeLayout(false);
            this.groupBoxVMBox.ResumeLayout(false);
            this.tabVend.ResumeLayout(false);
            this.tabVend.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLemon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOrange)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRegular)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabService.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.Button btn_RefillRack;
        private System.Windows.Forms.ListView listViewCanRack;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.GroupBox groupBoxCanRack;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ListView listViewVMCoinBox;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.Button btn_EmptyTransBox;
        private System.Windows.Forms.Button btn_EmptyVMBox;
        private System.Windows.Forms.ListView listViewTransBox;
        private System.Windows.Forms.GroupBox groupBoxVMBox;
        private System.Windows.Forms.TabPage tabVend;
        private System.Windows.Forms.Button btn_Nickel;
        private System.Windows.Forms.Button btn_Dime;
        private System.Windows.Forms.Button btn_Quarter;
        private System.Windows.Forms.Button btn_HalfDollar;
        private System.Windows.Forms.Button btn_Lemon;
        private System.Windows.Forms.Button btn_Orange;
        private System.Windows.Forms.Button btn_Regular;
        private System.Windows.Forms.Button btn_CoinReturn;
        private System.Windows.Forms.PictureBox pictureBoxLemon;
        private System.Windows.Forms.PictureBox pictureBoxOrange;
        private System.Windows.Forms.PictureBox pictureBoxRegular;
        private System.Windows.Forms.Label labelAmtEntered;
        private System.Windows.Forms.Label labelExactChange;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabService;
        private System.Windows.Forms.Button btn_SvcNotes;
    }
}

