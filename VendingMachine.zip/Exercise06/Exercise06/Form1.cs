﻿// Exercise 06.1 and 06.2
// Author: Montes, Jorge

using System;
using System.Collections.Generic;
using System.Windows.Forms;

using _06._0_Console_As_Library;

namespace Exercise06
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Create vending machine coin box
        private CoinBox vendMachineCoinBox = new CoinBox(new List<Coin> {
                new Coin(Coin.Denomination.QUARTER), new Coin(Coin.Denomination.DIME),
                new Coin(Coin.Denomination.NICKEL), new Coin(Coin.Denomination.QUARTER),
                new Coin(Coin.Denomination.QUARTER), new Coin(Coin.Denomination.DIME) });

        // Create can purchase transaction coin box
        private CoinBox transCoinBox = new CoinBox();

        // Set the price
        private PurchasePrice sodaPrice = new PurchasePrice(0.35M);

        // Create the can rack
        CanRack rack = new CanRack();

        // When form loads, set the price label dynamically
        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = string.Format("Please insert {0} cents for a can of soda", sodaPrice.Price);

            // Exact change required label is visible if we can't make change
            labelExactChange.Visible = !vendMachineCoinBox.CanMakeChange;
        }

        // Enter Half Dollar
        private void btn_HalfDollar_Click(object sender, EventArgs e)
        {
            Coin halfDollar = new Coin(Coin.Denomination.HALFDOLLAR);
            insertCoinInTransBox(halfDollar);
        }

        // Deposit coin, Update transaction box amount, and enable/disable soda dispense buttons
        private void insertCoinInTransBox(Coin ACoin)
        {
            transCoinBox.Deposit(ACoin);
            updTotalAmountEntered();
            dispenseButtonsEnable();
        }

        // Update Amount Entered label, Enable Coin Return button
        private void updTotalAmountEntered()
        {
            labelAmtEntered.Text = string.Format("Amount Entered: {0:C}", transCoinBox.ValueOf);
            btn_CoinReturn.Enabled = transCoinBox.ValueOf > 0M;
        }

        // If enough money entered to buy a soda, then enable dispense buttons
        private void dispenseButtonsEnable()
        {
            if (transCoinBox.ValueOf >= sodaPrice.PriceDecimal)
            {
                btn_Regular.Enabled = !rack.IsEmpty(Flavor.REGULAR);
                btn_Orange.Enabled = !rack.IsEmpty(Flavor.ORANGE);
                btn_Lemon.Enabled = !rack.IsEmpty(Flavor.LEMON);
            }
            else
            {
                btn_Regular.Enabled = false;
                btn_Orange.Enabled = false;
                btn_Lemon.Enabled = false;
            }

        }

        private void btn_Quarter_Click(object sender, EventArgs e)
        {
            Coin quarter = new Coin(Coin.Denomination.QUARTER);
            insertCoinInTransBox(quarter);
        }

        private void btn_Dime_Click(object sender, EventArgs e)
        {
            Coin dime = new Coin(Coin.Denomination.DIME);
            insertCoinInTransBox(dime);
        }

        private void btn_Nickel_Click(object sender, EventArgs e)
        {
            Coin nickel = new Coin(Coin.Denomination.NICKEL);
            insertCoinInTransBox(nickel);
        }

        private void btn_Regular_Click(object sender, EventArgs e)
        {
            dispenseSoda(Flavor.REGULAR);
        }

        private void btn_Orange_Click(object sender, EventArgs e)
        {
            dispenseSoda(Flavor.ORANGE);
        }

        private void btn_Lemon_Click(object sender, EventArgs e)
        {
            dispenseSoda(Flavor.LEMON);
        }

        // Dispense can of soda
        private void dispenseSoda(Flavor AFlavor)
        {
            decimal amountEntered = transCoinBox.ValueOf;

            // If enough money to buy a soda is entered, and rack is not empty, dispense soda
            if (transCoinBox.ValueOf >= sodaPrice.PriceDecimal && !rack.IsEmpty(AFlavor))
            {
                transCoinBox.Transfer(vendMachineCoinBox);      // Move money from transaction box to vending machine coin box
                updTotalAmountEntered();                        // Empty out Amount Entered label, and disable Coin Return button
                rack.RemoveACanOf(AFlavor);                     // Remove a can of soda
                MessageBox.Show(string.Format("Thanks. Here is your {0} soda.", AFlavor.ToString()));
                dispenseButtonsEnable();                        // Enable/disable soda dispense buttons

                // Calc and dispense change, if vending machine coin box can make change
                decimal changeDue = amountEntered - sodaPrice.PriceDecimal;
                if (changeDue > 0M && vendMachineCoinBox.CanMakeChange)
                {
                    vendMachineCoinBox.Withdraw(changeDue);
                    MessageBox.Show(string.Format("Here is your {0:c} in change.", changeDue));
                }
                // Display Exact Change label if not enough money to make change
                labelExactChange.Visible = !vendMachineCoinBox.CanMakeChange;
            }
        }

        private void btn_CoinReturn_Click(object sender, EventArgs e)
        {
            // If any money in the transaction coin box, return it and zero out the transaction box
            if (transCoinBox.ValueOf > 0M)
            {
                MessageBox.Show(string.Format("Here is your refund of {0:c}.", transCoinBox.ValueOf));
                transCoinBox.Withdraw(transCoinBox.ValueOf);
                updTotalAmountEntered();
            }

            // Disable soda dispense buttons
            dispenseButtonsEnable();
        }
    }
}
