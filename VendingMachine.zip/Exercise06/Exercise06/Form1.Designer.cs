﻿namespace Exercise06
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.labelExactChange = new System.Windows.Forms.Label();
            this.labelAmtEntered = new System.Windows.Forms.Label();
            this.pictureBoxRegular = new System.Windows.Forms.PictureBox();
            this.pictureBoxOrange = new System.Windows.Forms.PictureBox();
            this.pictureBoxLemon = new System.Windows.Forms.PictureBox();
            this.btn_CoinReturn = new System.Windows.Forms.Button();
            this.btn_Regular = new System.Windows.Forms.Button();
            this.btn_Orange = new System.Windows.Forms.Button();
            this.btn_Lemon = new System.Windows.Forms.Button();
            this.btn_HalfDollar = new System.Windows.Forms.Button();
            this.btn_Quarter = new System.Windows.Forms.Button();
            this.btn_Dime = new System.Windows.Forms.Button();
            this.btn_Nickel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRegular)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOrange)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLemon)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(104, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(288, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Please insert 35 cents for a can of soda";
            // 
            // labelExactChange
            // 
            this.labelExactChange.AutoSize = true;
            this.labelExactChange.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelExactChange.ForeColor = System.Drawing.Color.Red;
            this.labelExactChange.Location = new System.Drawing.Point(309, 266);
            this.labelExactChange.Name = "labelExactChange";
            this.labelExactChange.Size = new System.Drawing.Size(142, 15);
            this.labelExactChange.TabIndex = 1;
            this.labelExactChange.Text = "Exact change is required";
            // 
            // labelAmtEntered
            // 
            this.labelAmtEntered.AutoSize = true;
            this.labelAmtEntered.Location = new System.Drawing.Point(284, 295);
            this.labelAmtEntered.Name = "labelAmtEntered";
            this.labelAmtEntered.Size = new System.Drawing.Size(86, 13);
            this.labelAmtEntered.TabIndex = 2;
            this.labelAmtEntered.Text = "Amount Entered:";
            // 
            // pictureBoxRegular
            // 
            this.pictureBoxRegular.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxRegular.Image")));
            this.pictureBoxRegular.Location = new System.Drawing.Point(12, 84);
            this.pictureBoxRegular.Name = "pictureBoxRegular";
            this.pictureBoxRegular.Size = new System.Drawing.Size(126, 116);
            this.pictureBoxRegular.TabIndex = 3;
            this.pictureBoxRegular.TabStop = false;
            // 
            // pictureBoxOrange
            // 
            this.pictureBoxOrange.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxOrange.Image")));
            this.pictureBoxOrange.Location = new System.Drawing.Point(171, 84);
            this.pictureBoxOrange.Name = "pictureBoxOrange";
            this.pictureBoxOrange.Size = new System.Drawing.Size(132, 116);
            this.pictureBoxOrange.TabIndex = 4;
            this.pictureBoxOrange.TabStop = false;
            // 
            // pictureBoxLemon
            // 
            this.pictureBoxLemon.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLemon.Image")));
            this.pictureBoxLemon.Location = new System.Drawing.Point(335, 84);
            this.pictureBoxLemon.Name = "pictureBoxLemon";
            this.pictureBoxLemon.Size = new System.Drawing.Size(137, 116);
            this.pictureBoxLemon.TabIndex = 5;
            this.pictureBoxLemon.TabStop = false;
            // 
            // btn_CoinReturn
            // 
            this.btn_CoinReturn.Enabled = false;
            this.btn_CoinReturn.Location = new System.Drawing.Point(376, 351);
            this.btn_CoinReturn.Name = "btn_CoinReturn";
            this.btn_CoinReturn.Size = new System.Drawing.Size(75, 23);
            this.btn_CoinReturn.TabIndex = 6;
            this.btn_CoinReturn.Text = "Coin Return";
            this.btn_CoinReturn.UseVisualStyleBackColor = true;
            this.btn_CoinReturn.Click += new System.EventHandler(this.btn_CoinReturn_Click);
            // 
            // btn_Regular
            // 
            this.btn_Regular.Enabled = false;
            this.btn_Regular.Location = new System.Drawing.Point(35, 219);
            this.btn_Regular.Name = "btn_Regular";
            this.btn_Regular.Size = new System.Drawing.Size(75, 23);
            this.btn_Regular.TabIndex = 7;
            this.btn_Regular.Text = "Regular";
            this.btn_Regular.UseVisualStyleBackColor = true;
            this.btn_Regular.Click += new System.EventHandler(this.btn_Regular_Click);
            // 
            // btn_Orange
            // 
            this.btn_Orange.Enabled = false;
            this.btn_Orange.Location = new System.Drawing.Point(201, 219);
            this.btn_Orange.Name = "btn_Orange";
            this.btn_Orange.Size = new System.Drawing.Size(75, 23);
            this.btn_Orange.TabIndex = 8;
            this.btn_Orange.Text = "Orange";
            this.btn_Orange.UseVisualStyleBackColor = true;
            this.btn_Orange.Click += new System.EventHandler(this.btn_Orange_Click);
            // 
            // btn_Lemon
            // 
            this.btn_Lemon.Enabled = false;
            this.btn_Lemon.Location = new System.Drawing.Point(376, 219);
            this.btn_Lemon.Name = "btn_Lemon";
            this.btn_Lemon.Size = new System.Drawing.Size(75, 23);
            this.btn_Lemon.TabIndex = 9;
            this.btn_Lemon.Text = "Lemon";
            this.btn_Lemon.UseVisualStyleBackColor = true;
            this.btn_Lemon.Click += new System.EventHandler(this.btn_Lemon_Click);
            // 
            // btn_HalfDollar
            // 
            this.btn_HalfDollar.Location = new System.Drawing.Point(206, 322);
            this.btn_HalfDollar.Name = "btn_HalfDollar";
            this.btn_HalfDollar.Size = new System.Drawing.Size(75, 23);
            this.btn_HalfDollar.TabIndex = 10;
            this.btn_HalfDollar.Text = "Half Dollar";
            this.btn_HalfDollar.UseVisualStyleBackColor = true;
            this.btn_HalfDollar.Click += new System.EventHandler(this.btn_HalfDollar_Click);
            // 
            // btn_Quarter
            // 
            this.btn_Quarter.Location = new System.Drawing.Point(206, 351);
            this.btn_Quarter.Name = "btn_Quarter";
            this.btn_Quarter.Size = new System.Drawing.Size(75, 23);
            this.btn_Quarter.TabIndex = 11;
            this.btn_Quarter.Text = "Quarter";
            this.btn_Quarter.UseVisualStyleBackColor = true;
            this.btn_Quarter.Click += new System.EventHandler(this.btn_Quarter_Click);
            // 
            // btn_Dime
            // 
            this.btn_Dime.Location = new System.Drawing.Point(287, 322);
            this.btn_Dime.Name = "btn_Dime";
            this.btn_Dime.Size = new System.Drawing.Size(75, 23);
            this.btn_Dime.TabIndex = 12;
            this.btn_Dime.Text = "Dime";
            this.btn_Dime.UseVisualStyleBackColor = true;
            this.btn_Dime.Click += new System.EventHandler(this.btn_Dime_Click);
            // 
            // btn_Nickel
            // 
            this.btn_Nickel.Location = new System.Drawing.Point(287, 351);
            this.btn_Nickel.Name = "btn_Nickel";
            this.btn_Nickel.Size = new System.Drawing.Size(75, 23);
            this.btn_Nickel.TabIndex = 13;
            this.btn_Nickel.Text = "Nickel";
            this.btn_Nickel.UseVisualStyleBackColor = true;
            this.btn_Nickel.Click += new System.EventHandler(this.btn_Nickel_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 401);
            this.Controls.Add(this.btn_Nickel);
            this.Controls.Add(this.btn_Dime);
            this.Controls.Add(this.btn_Quarter);
            this.Controls.Add(this.btn_HalfDollar);
            this.Controls.Add(this.btn_Lemon);
            this.Controls.Add(this.btn_Orange);
            this.Controls.Add(this.btn_Regular);
            this.Controls.Add(this.btn_CoinReturn);
            this.Controls.Add(this.pictureBoxLemon);
            this.Controls.Add(this.pictureBoxOrange);
            this.Controls.Add(this.pictureBoxRegular);
            this.Controls.Add(this.labelAmtEntered);
            this.Controls.Add(this.labelExactChange);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Vending Machine";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRegular)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOrange)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLemon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelExactChange;
        private System.Windows.Forms.Label labelAmtEntered;
        private System.Windows.Forms.PictureBox pictureBoxRegular;
        private System.Windows.Forms.PictureBox pictureBoxOrange;
        private System.Windows.Forms.PictureBox pictureBoxLemon;
        private System.Windows.Forms.Button btn_CoinReturn;
        private System.Windows.Forms.Button btn_Regular;
        private System.Windows.Forms.Button btn_Orange;
        private System.Windows.Forms.Button btn_Lemon;
        private System.Windows.Forms.Button btn_HalfDollar;
        private System.Windows.Forms.Button btn_Quarter;
        private System.Windows.Forms.Button btn_Dime;
        private System.Windows.Forms.Button btn_Nickel;
    }
}

